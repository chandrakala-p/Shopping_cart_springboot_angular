export class Order {
    orderId: number = 0;
    orderName: string = "";
    orderPrice: string = "";
}
