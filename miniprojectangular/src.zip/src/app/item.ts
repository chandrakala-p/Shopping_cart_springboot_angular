export class Item {
    itemId: number = 0;
    itemName: string = "";
    itemPrice: string = "";

}
